from setuptools import setup, find_packages

setup(
name='crime_test', 
version='1.0',
install_requires=['pandas>=2.2.3']
)

